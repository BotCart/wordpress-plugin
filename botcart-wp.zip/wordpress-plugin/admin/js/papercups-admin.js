(function ($) {
  'use strict';

  $(document).ready(function ($) {
    $('.papercups-color-picker').iris();
  });
})(jQuery);
